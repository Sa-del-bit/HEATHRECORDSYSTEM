package com.healthrecords.model;

public enum UserRole {
    ROLE_PATIENT,
    ROLE_DOCTOR,
    ROLE_ADMIN
} 